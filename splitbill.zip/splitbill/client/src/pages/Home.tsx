import SplitBillCalculator from '@/components/SplitBillCalculator';

export default function Home() {
  return <SplitBillCalculator />;
}
