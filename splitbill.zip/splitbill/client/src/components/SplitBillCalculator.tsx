import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Trash2, Plus, DollarSign } from 'lucide-react';

interface Person {
  id: string;
  name: string;
}

/**
 * Design Philosophy: Minimalismo Moderno com Foco em Usabilidade
 * - Layout assimétrico: entrada à esquerda, resultado à direita
 * - Verde vibrante como acento (sucesso/dinheiro)
 * - Tipografia: Poppins para títulos, Inter para corpo
 * - Animações suaves e feedback imediato
 */
export default function SplitBillCalculator() {
  const [totalAmount, setTotalAmount] = useState<string>('');
  const [tipPercentage, setTipPercentage] = useState<string>('0');
  const [people, setPeople] = useState<Person[]>([
    { id: '1', name: 'Você' },
    { id: '2', name: 'Amigo' },
  ]);

  const calculateSplit = () => {
    const total = parseFloat(totalAmount) || 0;
    const tip = parseFloat(tipPercentage) || 0;
    const tipAmount = total * (tip / 100);
    const totalWithTip = total + tipAmount;
    const perPerson = totalWithTip / people.length;

    return {
      total,
      tipAmount,
      totalWithTip,
      perPerson,
      peopleCount: people.length,
    };
  };

  const handleAddPerson = () => {
    const newId = Date.now().toString();
    setPeople([...people, { id: newId, name: `Pessoa ${people.length + 1}` }]);
  };

  const handleRemovePerson = (id: string) => {
    if (people.length > 1) {
      setPeople(people.filter((p) => p.id !== id));
    }
  };

  const handleNameChange = (id: string, newName: string) => {
    setPeople(people.map((p) => (p.id === id ? { ...p, name: newName } : p)));
  };

  const result = calculateSplit();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-green-100 rounded-full">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <h1 className="text-4xl font-display text-slate-900 mb-2">SplitBill</h1>
          <p className="text-slate-600 font-body">Divida contas e gorjetas de forma simples e rápida</p>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left: Input Section */}
          <div className="space-y-6">
            <Card className="p-6 shadow-sm border-slate-200">
              <h2 className="text-lg font-display text-slate-900 mb-4">Detalhes da Conta</h2>

              {/* Total Amount */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Valor Total da Conta
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">R$</span>
                  <Input
                    type="number"
                    placeholder="0.00"
                    value={totalAmount}
                    onChange={(e) => setTotalAmount(e.target.value)}
                    className="pl-8 text-lg font-medium"
                    step="0.01"
                    min="0"
                  />
                </div>
              </div>

              {/* Tip Percentage */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Gorjeta (%)
                </label>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    placeholder="0"
                    value={tipPercentage}
                    onChange={(e) => setTipPercentage(e.target.value)}
                    className="text-lg font-medium"
                    step="1"
                    min="0"
                    max="100"
                  />
                  <div className="flex gap-2">
                    {[10, 15, 20].map((percent) => (
                      <Button
                        key={percent}
                        variant="outline"
                        size="sm"
                        onClick={() => setTipPercentage(percent.toString())}
                        className={`${
                          tipPercentage === percent.toString()
                            ? 'bg-green-50 border-green-300 text-green-700'
                            : ''
                        }`}
                      >
                        {percent}%
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            </Card>

            {/* People Section */}
            <Card className="p-6 shadow-sm border-slate-200">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-display text-slate-900">Participantes</h2>
                <span className="text-sm text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
                  {people.length}
                </span>
              </div>

              <div className="space-y-3 mb-4">
                {people.map((person) => (
                  <div key={person.id} className="flex items-center gap-2">
                    <Input
                      type="text"
                      value={person.name}
                      onChange={(e) => handleNameChange(person.id, e.target.value)}
                      className="flex-1 text-sm"
                      placeholder="Nome"
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemovePerson(person.id)}
                      disabled={people.length === 1}
                      className="text-slate-400 hover:text-red-500"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>

              <Button
                onClick={handleAddPerson}
                variant="outline"
                className="w-full border-dashed border-green-300 text-green-700 hover:bg-green-50"
              >
                <Plus className="w-4 h-4 mr-2" />
                Adicionar Pessoa
              </Button>
            </Card>
          </div>

          {/* Right: Result Section */}
          <div className="lg:sticky lg:top-8 h-fit">
            <Card className="p-8 shadow-lg border-0 bg-gradient-to-br from-green-50 to-emerald-50">
              <h2 className="text-lg font-display text-slate-900 mb-6">Resumo</h2>

              {totalAmount ? (
                <div className="space-y-4">
                  {/* Breakdown */}
                  <div className="space-y-3 pb-6 border-b border-green-200">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Valor da Conta:</span>
                      <span className="font-medium text-slate-900">
                        R$ {result.total.toFixed(2)}
                      </span>
                    </div>
                    {result.tipAmount > 0 && (
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-600">Gorjeta ({tipPercentage}%):</span>
                        <span className="font-medium text-slate-900">
                          R$ {result.tipAmount.toFixed(2)}
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Total:</span>
                      <span className="font-medium text-slate-900">
                        R$ {result.totalWithTip.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  {/* Per Person */}
                  <div className="text-center py-4">
                    <p className="text-sm text-slate-600 mb-2">Cada pessoa paga:</p>
                    <p className="text-4xl font-display text-green-600">
                      R$ {result.perPerson.toFixed(2)}
                    </p>
                    <p className="text-xs text-slate-500 mt-2">
                      Dividido entre {result.peopleCount} {result.peopleCount === 1 ? 'pessoa' : 'pessoas'}
                    </p>
                  </div>

                  {/* People Breakdown */}
                  <div className="space-y-2 pt-4 border-t border-green-200">
                    <p className="text-xs font-medium text-slate-600 uppercase tracking-wide">
                      Detalhes por Pessoa
                    </p>
                    {people.map((person) => (
                      <div key={person.id} className="flex justify-between text-sm">
                        <span className="text-slate-700">{person.name}</span>
                        <span className="font-semibold text-green-700">
                          R$ {result.perPerson.toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-slate-500 text-sm">
                    Insira o valor da conta para ver o cálculo
                  </p>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
