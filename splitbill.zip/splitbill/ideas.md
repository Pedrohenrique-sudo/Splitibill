# SplitBill - Design Brainstorm

## Resposta 1: Minimalismo Moderno com Foco em Usabilidade
**Design Movement:** Swiss Design + Modernismo Digital  
**Probability:** 0.08

### Core Principles
- Clareza absoluta: cada elemento tem um propósito
- Hierarquia visual forte através de tipografia e espaçamento
- Interações diretas e sem fricção
- Paleta neutra com um único acento vibrante

### Color Philosophy
- Fundo branco puro (ou cinza muito claro em modo escuro)
- Texto em cinza escuro/charcoal para máxima legibilidade
- Acento em verde vibrante (representa dinheiro/transação bem-sucedida)
- Bordas sutis em cinza claro para separação

### Layout Paradigm
- Estrutura assimétrica: entrada de dados à esquerda, resultado à direita
- Uso estratégico de whitespace para guiar o olho
- Cards com sombras muito sutis (apenas para profundidade)

### Signature Elements
1. Ícone de moeda/dinheiro com animação ao calcular
2. Divisor visual diagonal entre entrada e resultado
3. Badges coloridas para cada pessoa na divisão

### Interaction Philosophy
- Transições suaves ao digitar (sem delay)
- Feedback imediato em verde quando o cálculo é feito
- Hover effects sutis em botões (escurecimento leve)

### Animation
- Entrada de dados: fade-in suave (200ms)
- Cálculo: pulse sutil no resultado (300ms)
- Hover: scale 1.02 em botões com transição 150ms

### Typography System
- Display: **Poppins Bold** (títulos)
- Body: **Inter Regular** (texto principal)
- Números: **Courier New** (valores monetários para clareza)

---

## Resposta 2: Playful & Friendly (Estilo Startup Moderna)
**Design Movement:** Glassmorphism + Playful Minimalism  
**Probability:** 0.07

### Core Principles
- Acessível e amigável, sem parecer infantil
- Uso de cores vibrantes mas harmônicas
- Microinterações deliciosas em cada ação
- Sensação de comunidade e diversão

### Color Philosophy
- Gradiente suave: azul claro → roxo pastel
- Acentos em laranja quente para CTAs
- Fundo com padrão sutil (dots ou linhas)
- Texto em azul profundo para contraste

### Layout Paradigm
- Layout em grid 2 colunas: entrada e resultado lado a lado
- Cards com glassmorphism (fundo semi-transparente com blur)
- Animações ao entrar na página

### Signature Elements
1. Avatares coloridos para cada pessoa na divisão
2. Confete animado ao finalizar o cálculo
3. Ícones arredondados e amigáveis

### Interaction Philosophy
- Cliques geram feedback visual imediato (ripple effect)
- Hover em cards: elevação com sombra maior
- Adicionar/remover pessoas com animação suave

### Animation
- Entrada: slide-in com bounce (500ms)
- Cálculo: scale-up com rotação leve (400ms)
- Confete: 1s de animação ao finalizar

### Typography System
- Display: **Quicksand Bold** (títulos)
- Body: **Poppins Regular** (texto principal)
- Números: **Poppins SemiBold** (valores)

---

## Resposta 3: Premium & Sofisticado (Fintech Style)
**Design Movement:** Dark Mode Elegante + Neomorphism  
**Probability:** 0.06

### Core Principles
- Sofisticação e confiança (como um app bancário)
- Dark mode como padrão (reduz fadiga ocular)
- Tipografia elegante e espaçamento generoso
- Transições suaves e refinadas

### Color Philosophy
- Fundo: gradiente sutil de cinza escuro → preto
- Primário: ouro/dourado (luxo e precisão)
- Secundário: azul claro (confiança)
- Texto: branco com opacidade variável

### Layout Paradigm
- Layout em coluna única com cards expandíveis
- Uso de linhas horizontais elegantes como divisores
- Painel lateral com resumo de transações

### Signature Elements
1. Ícone de moeda em ouro com efeito de brilho
2. Linhas horizontais elegantes como separadores
3. Números em fonte monoespacial com tracking aumentado

### Interaction Philosophy
- Transições lentas e deliberadas (250-400ms)
- Hover: mudança sutil de cor com aumento de brilho
- Feedback de sucesso em ouro

### Animation
- Entrada: fade-in com movimento vertical suave (300ms)
- Cálculo: número "rolling" do resultado (600ms)
- Confirmação: brilho dourado pulsante (400ms)

### Typography System
- Display: **Playfair Display Bold** (títulos elegantes)
- Body: **Lato Regular** (texto legível e sofisticado)
- Números: **IBM Plex Mono** (precisão financeira)

---

## Decisão Final
Escolho a **Resposta 1: Minimalismo Moderno com Foco em Usabilidade** porque:
- É a mais clara e direta para resolver o problema real (divisão de contas)
- Não distrai com elementos decorativos desnecessários
- Funciona bem em qualquer dispositivo
- Transmite confiança e precisão (importante para cálculos financeiros)
- Fácil de entender de primeira (sem curva de aprendizado)
